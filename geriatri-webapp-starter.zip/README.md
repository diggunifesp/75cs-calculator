# Geriatri Webapp

Starter com Vite + TS + Tailwind + Alpine.